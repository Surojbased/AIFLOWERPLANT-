import os
from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_bcrypt import Bcrypt
# from flask_dance.contrib.google import make_google_blueprint, google  # Uncomment if using Google OAuth

from models import db  # Import db from models/__init__.py
from form import LoginForm  # Your WTForms login form

# =========================================
# Initialize Flask App
# =========================================
app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.environ.get("SESSION_SECRET", "fallback-secret-key")

# =========================================
# Database Config
# Replace with your MySQL URI if needed
# e.g. mysql+pymysql://user:password@localhost/dbname
# =========================================
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///flowers.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# =========================================
# Security (Password Hashing)
# =========================================
bcrypt = Bcrypt(app)


# =========================================
# Routes
# =========================================
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/home1.html")
def home1():
    return render_template("home1.html")

@app.route("/home2.html")
def home2():
    return render_template("home2.html")

@app.route("/home3.html")
def home3():
    return render_template("home3.html")

@app.route("/ai.html")
def ai():
    return render_template("ai.html")

@app.route("/about.html")
def about():
    return render_template("about.html")

@app.route("/contact.html")
def contact():
    return render_template("contact.html")

@app.route("/services.html")
def services():
    return render_template("services.html")

@app.route("/testimonials.html")
def testimonials():
    return render_template("testimonials.html")


# =========================================
# Database Init
# =========================================
def init_db():
    """Create database tables if they don’t exist."""
    with app.app_context():
        db.create_all()

# =========================================
# Error Handlers
# =========================================
@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404

# =========================================
# Entry Point
# =========================================
if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=8000)
