#!/usr/bin/env node

/**
 * SCSS Compiler Script
 * Compiles SCSS files to CSS for the Flower AI project
 * Usage: node compile-scss.js
 */

const fs = require('fs');
const path = require('path');
const sass = require('sass');

class SCSSCompiler {
    constructor() {
        this.projectRoot = process.cwd();
        this.stylesDir = path.join(this.projectRoot, 'styles');
        this.outputDir = path.join(this.projectRoot, 'css');
        this.mainFile = path.join(this.stylesDir, 'main.scss');
        this.outputFile = path.join(this.outputDir, 'compiled.css');
        
        this.options = {
            style: 'expanded',
            sourceMap: true,
            sourceMapContents: true,
            precision: 6,
            includePaths: [this.stylesDir]
        };
    }
    
    /**
     * Check if required directories and files exist
     */
    validateEnvironment() {
        const requiredPaths = [
            this.stylesDir,
            this.mainFile
        ];
        
        for (const pathToCheck of requiredPaths) {
            if (!fs.existsSync(pathToCheck)) {
                throw new Error(`Required path does not exist: ${pathToCheck}`);
            }
        }
        
        // Create output directory if it doesn't exist
        if (!fs.existsSync(this.outputDir)) {
            fs.mkdirSync(this.outputDir, { recursive: true });
            console.log(`Created output directory: ${this.outputDir}`);
        }
    }
    
    /**
     * Compile SCSS to CSS
     */
    async compile() {
        try {
            console.log('Starting SCSS compilation...');
            console.log(`Input: ${this.mainFile}`);
            console.log(`Output: ${this.outputFile}`);
            
            this.validateEnvironment();
            
            // Compile SCSS
            const result = sass.compile(this.mainFile, {
                style: 'expanded',
                sourceMap: true,
                loadPaths: [this.stylesDir]
            });
            
            // Write CSS file
            fs.writeFileSync(this.outputFile, result.css);
            console.log(`✓ CSS compiled successfully: ${this.outputFile}`);
            
            // Write source map if available
            if (result.sourceMap) {
                const sourceMapFile = this.outputFile + '.map';
                fs.writeFileSync(sourceMapFile, JSON.stringify(result.sourceMap));
                console.log(`✓ Source map generated: ${sourceMapFile}`);
            }
            
            // Generate minified version for production
            await this.generateMinified();
            
            console.log('✓ SCSS compilation completed successfully!');
            
        } catch (error) {
            console.error('❌ SCSS compilation failed:');
            console.error(error.message);
            
            if (error.span) {
                console.error(`Location: Line ${error.span.start.line + 1}, Column ${error.span.start.column + 1}`);
            }
            
            process.exit(1);
        }
    }
    
    /**
     * Generate minified CSS for production
     */
    async generateMinified() {
        try {
            const result = sass.compile(this.mainFile, {
                style: 'compressed',
                loadPaths: [this.stylesDir]
            });
            
            const minifiedFile = path.join(this.outputDir, 'compiled.min.css');
            fs.writeFileSync(minifiedFile, result.css);
            console.log(`✓ Minified CSS generated: ${minifiedFile}`);
            
        } catch (error) {
            console.warn('⚠️ Failed to generate minified CSS:', error.message);
        }
    }
    
    /**
     * Watch for changes and recompile
     */
    watch() {
        console.log('👀 Watching for SCSS changes...');
        console.log('Press Ctrl+C to stop watching\n');
        
        // Watch the entire styles directory
        fs.watch(this.stylesDir, { recursive: true }, (eventType, filename) => {
            if (filename && filename.endsWith('.scss')) {
                console.log(`📝 Detected change in: ${filename}`);
                this.compile().catch(console.error);
            }
        });
    }
    
    /**
     * Analyze SCSS files and generate report
     */
    analyze() {
        console.log('📊 Analyzing SCSS files...\n');
        
        const scssFiles = this.findSCSSFiles(this.stylesDir);
        let totalLines = 0;
        let totalSize = 0;
        
        console.log('SCSS Files Found:');
        scssFiles.forEach(file => {
            const relativePath = path.relative(this.projectRoot, file);
            const stats = fs.statSync(file);
            const content = fs.readFileSync(file, 'utf8');
            const lines = content.split('\n').length;
            
            totalLines += lines;
            totalSize += stats.size;
            
            console.log(`  ${relativePath} (${lines} lines, ${this.formatBytes(stats.size)})`);
        });
        
        console.log('\nSummary:');
        console.log(`  Total files: ${scssFiles.length}`);
        console.log(`  Total lines: ${totalLines}`);
        console.log(`  Total size: ${this.formatBytes(totalSize)}`);
        
        // Check if compiled CSS exists
        if (fs.existsSync(this.outputFile)) {
            const cssStats = fs.statSync(this.outputFile);
            console.log(`  Compiled CSS: ${this.formatBytes(cssStats.size)}`);
        }
    }
    
    /**
     * Find all SCSS files recursively
     */
    findSCSSFiles(dir) {
        let scssFiles = [];
        
        const files = fs.readdirSync(dir);
        files.forEach(file => {
            const filePath = path.join(dir, file);
            const stat = fs.statSync(filePath);
            
            if (stat.isDirectory()) {
                scssFiles = scssFiles.concat(this.findSCSSFiles(filePath));
            } else if (file.endsWith('.scss')) {
                scssFiles.push(filePath);
            }
        });
        
        return scssFiles;
    }
    
    /**
     * Format bytes to human readable format
     */
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    /**
     * Clean compiled files
     */
    clean() {
        console.log('🧹 Cleaning compiled files...');
        
        const filesToClean = [
            this.outputFile,
            this.outputFile + '.map',
            path.join(this.outputDir, 'compiled.min.css')
        ];
        
        filesToClean.forEach(file => {
            if (fs.existsSync(file)) {
                fs.unlinkSync(file);
                console.log(`✓ Removed: ${path.relative(this.projectRoot, file)}`);
            }
        });
        
        console.log('✓ Cleanup completed');
    }
}

// Main execution
async function main() {
    const compiler = new SCSSCompiler();
    const args = process.argv.slice(2);
    const command = args[0] || 'compile';
    
    try {
        switch (command) {
            case 'compile':
                await compiler.compile();
                break;
                
            case 'watch':
                await compiler.compile();
                compiler.watch();
                break;
                
            case 'analyze':
                compiler.analyze();
                break;
                
            case 'clean':
                compiler.clean();
                break;
                
            case '--help':
            case '-h':
                showHelp();
                break;
                
            default:
                console.error(`Unknown command: ${command}`);
                showHelp();
                process.exit(1);
        }
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        process.exit(1);
    }
}

/**
 * Show help information
 */
function showHelp() {
    console.log(`
Flower AI SCSS Compiler

Usage: node compile-scss.js [command]

Commands:
  compile    Compile SCSS to CSS (default)
  watch      Compile and watch for changes
  analyze    Analyze SCSS files and show statistics
  clean      Remove compiled CSS files
  --help     Show this help message

Examples:
  node compile-scss.js
  node compile-scss.js watch
  node compile-scss.js analyze
  node compile-scss.js clean

The compiler will:
- Compile styles/main.scss to css/compiled.css
- Generate source maps for debugging
- Create minified version for production
- Include all imported SCSS files
    `);
}

// Handle process termination gracefully
process.on('SIGINT', () => {
    console.log('\n👋 SCSS compiler stopped');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n👋 SCSS compiler terminated');
    process.exit(0);
});

// Run if called directly
if (require.main === module) {
    main();
}

module.exports = SCSSCompiler;
