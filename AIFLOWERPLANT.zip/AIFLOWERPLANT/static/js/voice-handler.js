/**
 * Voice Handler - Advanced Speech Recognition and Synthesis
 * Handles all voice-related functionality for the Flower AI application
 */

class VoiceHandler {
    constructor() {
        this.recognition = null;
        this.synthesis = window.speechSynthesis;
        this.isListening = false;
        this.isSupported = this.checkSupport();
        this.currentVoice = null;
        this.voices = [];
        
        // Voice settings
        this.settings = {
            language: 'en-US',
            continuous: false,
            interimResults: true,
            maxAlternatives: 1,
            rate: 1.0,
            pitch: 1.0,
            volume: 0.8
        };
        
        // Event callbacks
        this.callbacks = {
            onStart: null,
            onResult: null,
            onEnd: null,
            onError: null,
            onNoSpeech: null
        };
        
        this.init();
    }
    
    /**
     * Check if browser supports speech recognition and synthesis
     */
    checkSupport() {
        const hasRecognition = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
        const hasSynthesis = 'speechSynthesis' in window;
        
        if (!hasRecognition) {
            console.warn('Speech Recognition not supported in this browser');
        }
        
        if (!hasSynthesis) {
            console.warn('Speech Synthesis not supported in this browser');
        }
        
        return hasRecognition && hasSynthesis;
    }
    
    /**
     * Initialize voice recognition and synthesis
     */
    init() {
        if (!this.isSupported) {
            this.showUnsupportedMessage();
            return;
        }
        
        this.setupRecognition();
        this.setupSynthesis();
        this.setupEventListeners();
    }
    
    /**
     * Setup speech recognition
     */
    setupRecognition() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        
        // Configure recognition settings
        this.recognition.continuous = this.settings.continuous;
        this.recognition.interimResults = this.settings.interimResults;
        this.recognition.lang = this.settings.language;
        this.recognition.maxAlternatives = this.settings.maxAlternatives;
        
        // Event handlers
        this.recognition.onstart = () => {
            this.isListening = true;
            this.updateUI('listening');
            if (this.callbacks.onStart) this.callbacks.onStart();
            console.log('Voice recognition started');
        };
        
        this.recognition.onresult = (event) => {
            let finalTranscript = '';
            let interimTranscript = '';
            
            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcript = event.results[i][0].transcript;
                
                if (event.results[i].isFinal) {
                    finalTranscript += transcript;
                } else {
                    interimTranscript += transcript;
                }
            }
            
            if (this.callbacks.onResult) {
                this.callbacks.onResult(finalTranscript, interimTranscript);
            }
            
            if (finalTranscript) {
                console.log('Final transcript:', finalTranscript);
                this.processVoiceCommand(finalTranscript);
            }
        };
        
        this.recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.isListening = false;
            this.updateUI('error');
            
            if (this.callbacks.onError) {
                this.callbacks.onError(event.error);
            }
            
            this.handleRecognitionError(event.error);
        };
        
        this.recognition.onend = () => {
            this.isListening = false;
            this.updateUI('stopped');
            if (this.callbacks.onEnd) this.callbacks.onEnd();
            console.log('Voice recognition ended');
        };
        
        this.recognition.onnomatch = () => {
            console.log('No speech was recognized');
            if (this.callbacks.onNoSpeech) this.callbacks.onNoSpeech();
        };
    }
    
    /**
     * Setup speech synthesis
     */
    setupSynthesis() {
        // Load available voices
        this.loadVoices();
        
        // Reload voices when they change (some browsers load them asynchronously)
        this.synthesis.onvoiceschanged = () => {
            this.loadVoices();
        };
    }
    
    /**
     * Load available voices
     */
    loadVoices() {
        this.voices = this.synthesis.getVoices();
        
        // Prefer female English voices for flower AI
        const preferredVoices = [
            'Google UK English Female',
            'Google US English Female',
            'Microsoft Zira Desktop',
            'Apple Samantha',
            'Karen'
        ];
        
        for (const voiceName of preferredVoices) {
            const voice = this.voices.find(v => v.name.includes(voiceName));
            if (voice) {
                this.currentVoice = voice;
                break;
            }
        }
        
        // Fallback to first English voice
        if (!this.currentVoice) {
            this.currentVoice = this.voices.find(voice => voice.lang.startsWith('en')) || this.voices[0];
        }
        
        console.log('Available voices:', this.voices.length);
        console.log('Selected voice:', this.currentVoice?.name || 'Default');
    }
    
    /**
     * Setup event listeners for UI elements
     */
    setupEventListeners() {
        // Global voice button
        const globalVoiceBtn = document.getElementById('globalVoiceBtn');
        if (globalVoiceBtn) {
            globalVoiceBtn.addEventListener('click', () => this.toggleGlobalVoice());
        }
        
        // Voice intro button
        const voiceIntroBtn = document.getElementById('voiceIntroBtn');
        if (voiceIntroBtn) {
            voiceIntroBtn.addEventListener('click', () => this.startVoiceIntro());
        }
        
        // AI tool voice input button
        const voiceInputBtn = document.getElementById('voiceInputBtn');
        if (voiceInputBtn) {
            voiceInputBtn.addEventListener('click', () => this.startVoiceInput());
        }
        
        // Modal voice button
        const modalVoiceBtn = document.getElementById('modalVoiceBtn');
        if (modalVoiceBtn) {
            modalVoiceBtn.addEventListener('click', () => this.handleModalVoice());
        }
        
        // Quick prompt buttons
        const promptButtons = document.querySelectorAll('.btn-prompt');
        promptButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const prompt = btn.dataset.prompt;
                this.fillInput(prompt);
                this.speak(`I'll help you with: ${prompt}`);
            });
        });
    }
    
    /**
     * Start listening for voice input
     */
    startListening() {
        if (!this.isSupported || this.isListening) return;
        
        try {
            this.recognition.start();
        } catch (error) {
            console.error('Error starting voice recognition:', error);
            this.handleRecognitionError(error.message);
        }
    }
    
    /**
     * Stop listening for voice input
     */
    stopListening() {
        if (!this.isSupported || !this.isListening) return;
        
        try {
            this.recognition.stop();
        } catch (error) {
            console.error('Error stopping voice recognition:', error);
        }
    }
    
    /**
     * Toggle voice listening
     */
    toggleListening() {
        if (this.isListening) {
            this.stopListening();
        } else {
            this.startListening();
        }
    }
    
    /**
     * Speak text using speech synthesis
     */
    speak(text, options = {}) {
        if (!this.isSupported) return;
        
        // Cancel any ongoing speech
        this.synthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        
        // Apply settings
        utterance.voice = options.voice || this.currentVoice;
        utterance.rate = options.rate || this.settings.rate;
        utterance.pitch = options.pitch || this.settings.pitch;
        utterance.volume = options.volume || this.settings.volume;
        
        // Event handlers
        utterance.onstart = () => {
            console.log('Speech synthesis started');
            this.updateUI('speaking');
        };
        
        utterance.onend = () => {
            console.log('Speech synthesis ended');
            this.updateUI('ready');
        };
        
        utterance.onerror = (error) => {
            console.error('Speech synthesis error:', error);
            this.updateUI('error');
        };
        
        // Speak the text
        this.synthesis.speak(utterance);
        
        return utterance;
    }
    
    /**
     * Process voice commands
     */
    processVoiceCommand(transcript) {
        const command = transcript.toLowerCase().trim();
        
        // Command patterns
        const commands = {
            greeting: /^(hello|hi|hey)/,
            help: /^(help|what can you do)/,
            flowers: /flowers?|bloom/,
            morning: /morning/,
            evening: /evening/,
            night: /night/,
            care: /care|how to/,
            generate: /generate|create|tell me about/
        };
        
        let response = '';
        
        if (commands.greeting.test(command)) {
            response = "Hello! I'm your flower AI assistant. I can help you learn about flowers and their bloom times. What would you like to know?";
        } else if (commands.help.test(command)) {
            response = "I can help you learn about flowers that bloom at different times, provide care instructions, and generate information about flower characteristics. Try asking about morning, evening, or night blooming flowers!";
        } else if (commands.morning.test(command)) {
            response = "Morning blooming flowers like sunflowers and morning glories open with the sunrise. They're perfect for early garden walks and typically close during the heat of the day.";
        } else if (commands.evening.test(command)) {
            response = "Evening bloomers such as four o'clock flowers and evening primrose open as the day cools down, creating beautiful sunset gardens with gentle fragrances.";
        } else if (commands.night.test(command)) {
            response = "Night blooming flowers like moonflowers and night jasmine open under moonlight, often with intense fragrances to attract nocturnal pollinators like moths and bats.";
        } else if (commands.flowers.test(command) || commands.generate.test(command)) {
            // Fill the AI input with the transcript and trigger generation
            this.fillInput(transcript);
            response = "I've added your question to the AI tool. Let me generate some information for you.";
            setTimeout(() => {
                document.getElementById('generateBtn')?.click();
            }, 1000);
        } else {
            // Default response for unrecognized commands
            response = "That's an interesting question about flowers! Let me add it to the AI tool to generate a detailed response for you.";
            this.fillInput(transcript);
        }
        
        if (response) {
            this.speak(response);
        }
    }
    
    /**
     * Handle different voice interaction modes
     */
    toggleGlobalVoice() {
        const modal = new bootstrap.Modal(document.getElementById('voiceModal'));
        modal.show();
        
        this.speak("Voice assistant activated. How can I help you learn about flowers today?");
    }
    
    startVoiceIntro() {
        this.speak("Welcome to Flower AI! I can help you discover the fascinating world of flowers through voice interactions. You can ask me about bloom times, flower care, or any flower-related questions. Try saying 'tell me about morning flowers' or 'how do I care for roses'.");
    }
    
    startVoiceInput() {
        this.showVoiceFeedback();
        
        this.callbacks.onResult = (final, interim) => {
            const input = document.getElementById('aiInput');
            if (input) {
                input.value = final + interim;
            }
        };
        
        this.callbacks.onEnd = () => {
            this.hideVoiceFeedback();
        };
        
        this.startListening();
    }
    
    handleModalVoice() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('voiceModal'));
        
        this.callbacks.onResult = (final, interim) => {
            // Update modal content with transcription
            const modalText = document.getElementById('voiceModalText');
            if (modalText) {
                modalText.textContent = final || interim || 'Listening...';
            }
        };
        
        this.callbacks.onEnd = () => {
            setTimeout(() => modal.hide(), 2000);
        };
        
        this.startListening();
    }
    
    /**
     * Fill input field with text
     */
    fillInput(text) {
        const input = document.getElementById('aiInput');
        if (input) {
            input.value = text;
            input.focus();
        }
    }
    
    /**
     * Show voice feedback UI
     */
    showVoiceFeedback() {
        const feedback = document.getElementById('voiceFeedback');
        if (feedback) {
            feedback.classList.add('active');
        }
        
        const voiceBtn = document.getElementById('voiceInputBtn');
        if (voiceBtn) {
            voiceBtn.classList.add('listening');
        }
    }
    
    /**
     * Hide voice feedback UI
     */
    hideVoiceFeedback() {
        const feedback = document.getElementById('voiceFeedback');
        if (feedback) {
            feedback.classList.remove('active');
        }
        
        const voiceBtn = document.getElementById('voiceInputBtn');
        if (voiceBtn) {
            voiceBtn.classList.remove('listening');
        }
    }
    
    /**
     * Update UI based on voice state
     */
    updateUI(state) {
        const voiceStatus = document.getElementById('voiceStatus');
        const voiceIndicator = voiceStatus?.querySelector('.voice-indicator');
        const voiceText = voiceStatus?.querySelector('.voice-text');
        
        if (!voiceIndicator || !voiceText) return;
        
        // Remove all state classes
        voiceIndicator.classList.remove('listening', 'speaking', 'error');
        
        switch (state) {
            case 'listening':
                voiceIndicator.classList.add('listening');
                voiceText.textContent = 'Listening...';
                voiceIndicator.innerHTML = '<div class="pulse-ring"></div><div class="pulse-ring pulse-ring-2"></div><div class="pulse-ring pulse-ring-3"></div><i class="fas fa-microphone"></i>';
                break;
                
            case 'speaking':
                voiceIndicator.classList.add('speaking');
                voiceText.textContent = 'Speaking...';
                voiceIndicator.innerHTML = '<div class="pulse-ring"></div><div class="pulse-ring pulse-ring-2"></div><div class="pulse-ring pulse-ring-3"></div><i class="fas fa-volume-up"></i>';
                break;
                
            case 'error':
                voiceIndicator.classList.add('error');
                voiceText.textContent = 'Voice Error';
                voiceIndicator.innerHTML = '<i class="fas fa-exclamation-triangle"></i>';
                break;
                
            case 'ready':
            case 'stopped':
            default:
                voiceText.textContent = 'Voice Ready';
                voiceIndicator.innerHTML = '<div class="pulse-ring"></div><div class="pulse-ring pulse-ring-2"></div><div class="pulse-ring pulse-ring-3"></div><i class="fas fa-microphone-slash"></i>';
                break;
        }
    }
    
    /**
     * Handle recognition errors
     */
    handleRecognitionError(error) {
        let message = '';
        
        switch (error) {
            case 'no-speech':
                message = "No speech was detected. Please try again.";
                break;
            case 'audio-capture':
                message = "Microphone access was denied. Please check your browser settings.";
                break;
            case 'not-allowed':
                message = "Microphone permission is required for voice features.";
                break;
            case 'network':
                message = "Network error occurred. Please check your connection.";
                break;
            default:
                message = "Voice recognition error occurred. Please try again.";
                break;
        }
        
        this.showNotification(message, 'error');
    }
    
    /**
     * Show unsupported browser message
     */
    showUnsupportedMessage() {
        this.showNotification(
            'Voice features are not supported in this browser. Please use Chrome, Edge, or Safari for the best experience.',
            'warning'
        );
    }
    
    /**
     * Show notification to user
     */
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 100px; right: 20px; z-index: 9999; max-width: 400px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
    
    /**
     * Set voice recognition language
     */
    setLanguage(language) {
        this.settings.language = language;
        if (this.recognition) {
            this.recognition.lang = language;
        }
    }
    
    /**
     * Set speech synthesis voice
     */
    setVoice(voiceName) {
        const voice = this.voices.find(v => v.name === voiceName);
        if (voice) {
            this.currentVoice = voice;
        }
    }
    
    /**
     * Get current status
     */
    getStatus() {
        return {
            isSupported: this.isSupported,
            isListening: this.isListening,
            currentVoice: this.currentVoice?.name || 'Default',
            language: this.settings.language,
            voicesAvailable: this.voices.length
        };
    }
    
    /**
     * Cleanup resources
     */
    destroy() {
        if (this.recognition) {
            this.recognition.stop();
            this.recognition = null;
        }
        
        if (this.synthesis) {
            this.synthesis.cancel();
        }
        
        this.callbacks = {};
    }
}

// Export for global use
window.VoiceHandler = VoiceHandler;
