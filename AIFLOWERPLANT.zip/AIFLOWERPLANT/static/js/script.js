// AI Flower Plant Landing Page - Main JavaScript
class AIFlowerPlant {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeAnimations();
        this.setupNavigation();
        this.setupScrollEffects();
        this.setupFormHandlers();
        this.initializeMobileMenu();
    }

    setupEventListeners() {
        // DOM Content Loaded
        document.addEventListener('DOMContentLoaded', () => {
            this.onPageLoad();
        });

        // Window events
        window.addEventListener('scroll', this.throttle(this.handleScroll.bind(this), 16));
        window.addEventListener('resize', this.throttle(this.handleResize.bind(this), 250));
        window.addEventListener('load', () => {
            this.revealAnimatedElements();
        });
    }

    onPageLoad() {
        // Fade in initial elements
        this.fadeInElements('.fade-in-up', 100);
        this.fadeInElements('.fade-in-left', 200);
        this.fadeInElements('.fade-in-right', 300);
        
        // Initialize intersection observer for scroll animations
        this.initScrollAnimations();
        
        // Add scroll to top button
        this.createScrollToTopButton();
    }

    setupNavigation() {
        const navbar = document.querySelector('.navbar');
        const navLinks = document.querySelectorAll('.nav-link[href^="#"]');
        
        // Smooth scroll for anchor links
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                this.scrollToSection(targetId);
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Dropdown functionality
        this.setupDropdowns();
    }

    setupDropdowns() {
        const dropdowns = document.querySelectorAll('.dropdown');
        
        dropdowns.forEach(dropdown => {
            const toggle = dropdown.querySelector('.dropdown-toggle');
            const menu = dropdown.querySelector('.dropdown-menu');
            
            if (window.innerWidth <= 1023) {
                // Mobile dropdown behavior
                toggle.addEventListener('click', (e) => {
                    e.preventDefault();
                    dropdown.classList.toggle('mobile-active');
                });
            }
        });
    }

    initializeMobileMenu() {
        const mobileToggle = document.querySelector('.mobile-menu-toggle');
        const navMenu = document.querySelector('.nav-menu');
        const navLinks = document.querySelectorAll('.nav-link');

        if (mobileToggle && navMenu) {
            mobileToggle.addEventListener('click', () => {
                mobileToggle.classList.toggle('active');
                navMenu.classList.toggle('mobile-active');
                document.body.style.overflow = navMenu.classList.contains('mobile-active') ? 'hidden' : '';
            });

            // Close menu when clicking on a link
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    if (navMenu.classList.contains('mobile-active')) {
                        mobileToggle.classList.remove('active');
                        navMenu.classList.remove('mobile-active');
                        document.body.style.overflow = '';
                    }
                });
            });

            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!navMenu.contains(e.target) && !mobileToggle.contains(e.target)) {
                    mobileToggle.classList.remove('active');
                    navMenu.classList.remove('mobile-active');
                    document.body.style.overflow = '';
                }
            });
        }
    }

    setupScrollEffects() {
        // Parallax effect for background elements
        const parallaxElements = document.querySelectorAll('.hero-background, .floating-particles');
        
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            
            parallaxElements.forEach(element => {
                element.style.transform = `translateY(${rate}px)`;
            });
        });

        // Floating animation stagger
        this.staggerFloatingAnimations();
    }

    initScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animated');
                    
                    // Stagger animation for multiple elements
                    if (entry.target.closest('.stagger-animation')) {
                        this.staggerChildAnimations(entry.target);
                    }
                }
            });
        }, observerOptions);

        // Observe elements with animation classes
        const animatedElements = document.querySelectorAll(
            '.animate-on-scroll, .animate-slide-left, .animate-slide-right, .animate-scale, ' +
            '.flower-category, .floating-card, .ai-node, .contact-item'
        );

        animatedElements.forEach(element => {
            observer.observe(element);
        });
    }

    staggerChildAnimations(container) {
        const children = container.querySelectorAll('.animate-on-scroll');
        children.forEach((child, index) => {
            setTimeout(() => {
                child.classList.add('animated');
            }, index * 150);
        });
    }

    fadeInElements(selector, delay = 0) {
        const elements = document.querySelectorAll(selector);
        elements.forEach((element, index) => {
            setTimeout(() => {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, delay + (index * 100));
        });
    }

    staggerFloatingAnimations() {
        const floatingCards = document.querySelectorAll('.floating-card');
        floatingCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.3}s`;
        });

        const flowerCards = document.querySelectorAll('.flower-card');
        flowerCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.5}s`;
        });
    }

    setupFormHandlers() {
        // Contact form
        const contactForm = document.querySelector('.contact-form form');
        if (contactForm) {
            contactForm.addEventListener('submit', this.handleContactForm.bind(this));
        }

        // Newsletter form
        const newsletterForm = document.querySelector('.newsletter-form');
        if (newsletterForm) {
            newsletterForm.addEventListener('submit', this.handleNewsletterForm.bind(this));
        }

        // Add input animations
        this.setupInputAnimations();
    }

    setupInputAnimations() {
        const inputs = document.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('focus', () => {
                input.parentElement.classList.add('focused');
            });

            input.addEventListener('blur', () => {
                if (!input.value) {
                    input.parentElement.classList.remove('focused');
                }
            });

            // Check if input has value on load
            if (input.value) {
                input.parentElement.classList.add('focused');
            }
        });
    }

    handleContactForm(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);

        // Simulate form submission
        this.showNotification('Thank you for your message! We\'ll get back to you soon.', 'success');
        e.target.reset();
    }

    handleNewsletterForm(e) {
        e.preventDefault();
        const email = e.target.querySelector('input[type="email"]').value;
        
        if (this.validateEmail(email)) {
            this.showNotification('Successfully subscribed to our newsletter!', 'success');
            e.target.reset();
        } else {
            this.showNotification('Please enter a valid email address.', 'error');
        }
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? 'var(--accent-color)' : type === 'error' ? '#ef4444' : 'var(--primary-color)'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            z-index: 10000;
            transform: translateX(100%);
            transition: transform 0.3s ease;
            max-width: 300px;
            word-wrap: break-word;
        `;
        notification.textContent = message;

        document.body.appendChild(notification);

        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);

        // Remove after 5 seconds
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }

    createScrollToTopButton() {
        const scrollToTop = document.createElement('button');
        scrollToTop.className = 'scroll-to-top';
        scrollToTop.innerHTML = '<i class="fas fa-arrow-up"></i>';
        scrollToTop.setAttribute('aria-label', 'Scroll to top');
        
        scrollToTop.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        document.body.appendChild(scrollToTop);

        // Show/hide based on scroll position
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollToTop.classList.add('visible');
            } else {
                scrollToTop.classList.remove('visible');
            }
        });
    }

    handleScroll() {
        const scrolled = window.pageYOffset;
        
        // Update progress indicator
        this.updateScrollProgress();
        
        // Navbar hide/show on scroll
        this.handleNavbarScroll();
        
        // Reveal elements on scroll
        this.revealOnScroll();
    }

    updateScrollProgress() {
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        
        // Update any progress indicators
        const progressBars = document.querySelectorAll('.scroll-progress');
        progressBars.forEach(bar => {
            bar.style.width = scrolled + '%';
        });
    }

    handleNavbarScroll() {
        const navbar = document.querySelector('.navbar');
        const currentScroll = window.pageYOffset;
        
        if (!this.lastScrollTop) this.lastScrollTop = 0;
        
        if (currentScroll > this.lastScrollTop && currentScroll > 100) {
            // Scrolling down
            navbar.classList.add('scroll-down');
            navbar.classList.remove('scroll-up');
        } else {
            // Scrolling up
            navbar.classList.remove('scroll-down');
            navbar.classList.add('scroll-up');
        }
        
        this.lastScrollTop = currentScroll;
    }

    revealOnScroll() {
        const elements = document.querySelectorAll('.reveal-on-scroll');
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementTop < window.innerHeight - elementVisible) {
                element.classList.add('revealed');
            }
        });
    }

    revealAnimatedElements() {
        // Trigger animations for elements that should animate on load
        const heroElements = document.querySelectorAll('.hero .fade-in-up, .hero .fade-in-left, .hero .fade-in-right');
        heroElements.forEach((element, index) => {
            setTimeout(() => {
                element.classList.add('animated');
            }, index * 200);
        });
    }

    handleResize() {
        // Recalculate any size-dependent features
        this.setupDropdowns();
        
        // Update mobile menu behavior
        if (window.innerWidth > 1023) {
            const navMenu = document.querySelector('.nav-menu');
            const mobileToggle = document.querySelector('.mobile-menu-toggle');
            
            if (navMenu && mobileToggle) {
                navMenu.classList.remove('mobile-active');
                mobileToggle.classList.remove('active');
                document.body.style.overflow = '';
            }
        }
    }

    // Utility function to scroll to a section
    scrollToSection(sectionId) {
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            const offsetTop = targetSection.getBoundingClientRect().top + window.pageYOffset - 70;
            
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    }

    // Throttle function for performance
    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    }

    // Initialize interactive elements
    initializeAnimations() {
        // Add hover effects to cards
        this.setupCardHoverEffects();
        
        // Initialize AI diagram interactions
        this.initializeAIDiagram();
        
        // Setup flower category interactions
        this.setupFlowerCategoryEffects();
    }

    setupCardHoverEffects() {
        const cards = document.querySelectorAll('.floating-card, .flower-card');
        
        cards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
            });
        });
    }

    initializeAIDiagram() {
        const aiNodes = document.querySelectorAll('.ai-node');
        
        aiNodes.forEach((node, index) => {
            // Add click interactions
            node.addEventListener('click', () => {
                this.showAINodeInfo(index);
            });
            
            // Add hover effects
            node.addEventListener('mouseenter', () => {
                node.style.transform = 'scale(1.15)';
                node.style.boxShadow = '0 10px 25px rgba(0,0,0,0.2)';
            });
            
            node.addEventListener('mouseleave', () => {
                node.style.transform = '';
                node.style.boxShadow = '';
            });
        });
    }

    showAINodeInfo(nodeIndex) {
        const nodeInfo = [
            'AI Core Processing Unit - Central brain of the system',
            'Temperature Monitoring - Tracks optimal growing conditions',
            'Moisture Control - Maintains perfect hydration levels',
            'Light Management - Optimizes photosynthesis cycles',
            'Network Connectivity - Remote monitoring and control'
        ];
        
        this.showNotification(nodeInfo[nodeIndex] || 'AI Technology Node', 'info');
    }

    setupFlowerCategoryEffects() {
        const categories = document.querySelectorAll('.flower-category');
        
        categories.forEach(category => {
            const cards = category.querySelectorAll('.floating-card');
            
            category.addEventListener('mouseenter', () => {
                cards.forEach((card, index) => {
                    setTimeout(() => {
                        card.style.transform = 'translateY(-5px)';
                    }, index * 100);
                });
            });
            
            category.addEventListener('mouseleave', () => {
                cards.forEach(card => {
                    card.style.transform = '';
                });
            });
        });
    }
}

// Global functions for inline event handlers
window.scrollToSection = function(sectionId) {
    const aiFlowerPlant = new AIFlowerPlant();
    aiFlowerPlant.scrollToSection(sectionId);
};

// Initialize the application
const aiFlowerPlant = new AIFlowerPlant();

// Export for use in other scripts if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AIFlowerPlant;
}
