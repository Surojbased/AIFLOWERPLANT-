/**
 * Main Application - Flower AI Landing Page
 * Coordinates all functionality and manages application state
 */

class FlowerAI {
    constructor() {
        this.voiceHandler = null;
        this.animationManager = null;
        this.isInitialized = false;
        this.currentSection = 'home';
        
        // Application state
        this.state = {
            voiceEnabled: false,
            currentQuery: '',
            isGenerating: false,
            lastResponse: null
        };
        
        // Initialize when DOM is ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            this.init();
        }
    }
    
    /**
     * Initialize the application
     */
    async init() {
        if (this.isInitialized) return;
        
        try {
            console.log('Initializing Flower AI Application...');
            
            // Initialize core systems
            await this.initializeAnimations();
            await this.initializeVoice();
            await this.setupEventListeners();
            await this.setupAITool();
            await this.setupNavigation();
            
            // Setup responsive behavior
            this.setupResponsiveFeatures();
            
            // Initialize accessibility features
            this.setupAccessibility();
            
            // Show welcome message
            this.showWelcomeMessage();
            
            this.isInitialized = true;
            console.log('Flower AI Application initialized successfully');
            
        } catch (error) {
            console.error('Error initializing Flower AI:', error);
            this.handleInitializationError(error);
        }
    }
    
    /**
     * Initialize animation system
     */
    async initializeAnimations() {
        try {
            this.animationManager = new AnimationManager();
            console.log('Animations initialized');
        } catch (error) {
            console.error('Error initializing animations:', error);
        }
    }
    
    /**
     * Initialize voice handler
     */
    async initializeVoice() {
        try {
            this.voiceHandler = new VoiceHandler();
            this.state.voiceEnabled = this.voiceHandler.isSupported;
            
            if (this.state.voiceEnabled) {
                console.log('Voice features enabled');
                this.setupVoiceIntegration();
            } else {
                console.warn('Voice features not available');
                this.disableVoiceFeatures();
            }
        } catch (error) {
            console.error('Error initializing voice handler:', error);
            this.disableVoiceFeatures();
        }
    }
    
    /**
     * Setup main event listeners
     */
    async setupEventListeners() {
        // Get Started Button
        const getStartedBtn = document.getElementById('getStartedBtn');
        if (getStartedBtn) {
            getStartedBtn.addEventListener('click', () => {
                this.scrollToSection('flowers');
                this.trackEvent('get_started_clicked');
            });
        }
        
        // Learn More Buttons
        const learnMoreBtns = document.querySelectorAll('.btn-learn-more');
        learnMoreBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const flowerType = e.target.dataset.flowerType;
                this.handleLearnMore(flowerType);
            });
        });
        
        // Quick Prompt Buttons
        const promptBtns = document.querySelectorAll('.btn-prompt');
        promptBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const prompt = e.target.dataset.prompt;
                this.handleQuickPrompt(prompt);
            });
        });
        
        // Window events
        window.addEventListener('resize', () => this.handleResize());
        window.addEventListener('scroll', () => this.handleScroll());
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
    }
    
    /**
     * Setup AI tool functionality
     */
    async setupAITool() {
        const generateBtn = document.getElementById('generateBtn');
        const clearBtn = document.getElementById('clearBtn');
        const aiInput = document.getElementById('aiInput');
        
        if (generateBtn) {
            generateBtn.addEventListener('click', () => this.generateAIResponse());
        }
        
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearAITool());
        }
        
        if (aiInput) {
            // Auto-resize textarea
            aiInput.addEventListener('input', () => {
                this.autoResizeTextarea(aiInput);
            });
            
            // Enter to generate (Ctrl+Enter)
            aiInput.addEventListener('keydown', (e) => {
                if (e.ctrlKey && e.key === 'Enter') {
                    this.generateAIResponse();
                }
            });
        }
    }
    
    /**
     * Setup navigation functionality
     */
    async setupNavigation() {
        // Smooth scroll for navigation links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                if (href.startsWith('#')) {
                    e.preventDefault();
                    const targetId = href.substring(1);
                    this.scrollToSection(targetId);
                }
            });
        });
        
        // Active section tracking
        this.setupActiveSection();
    }
    
    /**
     * Setup voice integration
     */
    setupVoiceIntegration() {
        if (!this.voiceHandler) return;
        
        // Set voice callbacks
        this.voiceHandler.callbacks.onResult = (final, interim) => {
            this.handleVoiceResult(final, interim);
        };
        
        this.voiceHandler.callbacks.onStart = () => {
            this.handleVoiceStart();
        };
        
        this.voiceHandler.callbacks.onEnd = () => {
            this.handleVoiceEnd();
        };
        
        this.voiceHandler.callbacks.onError = (error) => {
            this.handleVoiceError(error);
        };
    }
    
    /**
     * Handle learn more button clicks
     */
    handleLearnMore(flowerType) {
        const prompts = {
            morning: "Tell me about flowers that bloom in the morning, their characteristics, and care instructions.",
            evening: "Explain evening blooming flowers, when they open, and what makes them special.",
            night: "Describe night blooming flowers, their unique features, and nocturnal pollination."
        };
        
        const prompt = prompts[flowerType] || "Tell me about different types of flowers.";
        
        // Fill AI input and scroll to it
        this.fillAIInput(prompt);
        this.scrollToSection('ai-tool');
        
        // Generate response after a short delay
        setTimeout(() => {
            this.generateAIResponse();
        }, 1000);
        
        this.trackEvent('learn_more_clicked', { flowerType });
    }
    
    /**
     * Handle quick prompt selection
     */
    handleQuickPrompt(prompt) {
        this.fillAIInput(prompt);
        
        if (this.state.voiceEnabled) {
            this.voiceHandler.speak(`I'll help you with: ${prompt}`);
        }
        
        this.trackEvent('quick_prompt_selected', { prompt });
    }
    
    /**
     * Generate AI response
     */
    async generateAIResponse() {
        const input = document.getElementById('aiInput');
        const result = document.getElementById('aiResult');
        const generateBtn = document.getElementById('generateBtn');
        
        if (!input || !result || !generateBtn) return;
        
        const query = input.value.trim();
        if (!query) {
            this.showNotification('Please enter a question about flowers.', 'warning');
            input.focus();
            return;
        }
        
        try {
            this.state.isGenerating = true;
            this.state.currentQuery = query;
            
            // Update UI
            generateBtn.disabled = true;
            generateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating...';
            result.classList.add('loading');
            result.innerHTML = '<div class="loading-spinner"></div>';
            
            // Show loading overlay
            if (window.showLoading) window.showLoading();
            
            // Simulate AI processing (replace with actual AI API call)
            const response = await this.callAIService(query);
            
            // Display response
            this.displayAIResponse(response);
            
            // Voice feedback
            if (this.state.voiceEnabled) {
                setTimeout(() => {
                    this.voiceHandler.speak("I've generated information about your flower question. The response is now displayed below.");
                }, 500);
            }
            
            this.trackEvent('ai_response_generated', { query, responseLength: response.length });
            
        } catch (error) {
            console.error('Error generating AI response:', error);
            this.displayAIError(error);
        } finally {
            this.state.isGenerating = false;
            
            // Reset UI
            generateBtn.disabled = false;
            generateBtn.innerHTML = '<i class="fas fa-magic me-2"></i>Generate';
            result.classList.remove('loading');
            
            // Hide loading overlay
            if (window.hideLoading) window.hideLoading();
        }
    }
    
    /**
     * Call AI service (simulate or integrate with actual API)
     */
    async callAIService(query) {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Generate contextual response based on query keywords
        const responses = this.generateContextualResponse(query);
        return responses;
    }
    
    /**
     * Generate contextual response based on query
     */
    generateContextualResponse(query) {
        const lowerQuery = query.toLowerCase();
        
        // Flower care responses
        if (lowerQuery.includes('care') || lowerQuery.includes('how to')) {
            return {
                title: "Flower Care Guidelines",
                content: `
                    <p>Here are essential care tips for healthy flowers:</p>
                    <ul>
                        <li><strong>Watering:</strong> Water deeply but less frequently, allowing soil to dry between waterings</li>
                        <li><strong>Sunlight:</strong> Most flowers need 6-8 hours of direct sunlight daily</li>
                        <li><strong>Soil:</strong> Use well-draining soil rich in organic matter</li>
                        <li><strong>Fertilizing:</strong> Feed with balanced fertilizer during growing season</li>
                        <li><strong>Pruning:</strong> Remove dead flowers to encourage continued blooming</li>
                    </ul>
                    <p>Specific care requirements vary by flower type, so always research your particular species for best results.</p>
                `
            };
        }
        
        // Morning flowers
        if (lowerQuery.includes('morning')) {
            return {
                title: "Morning Blooming Flowers",
                content: `
                    <p>Morning bloomers are flowers that open their petals with the sunrise, typically between 5-9 AM:</p>
                    <ul>
                        <li><strong>Sunflowers:</strong> Track the sun throughout the day, opening at dawn</li>
                        <li><strong>Morning Glory:</strong> Trumpet-shaped flowers that close in afternoon heat</li>
                        <li><strong>Daisies:</strong> Open early and stay open throughout the day</li>
                        <li><strong>Poppies:</strong> Delicate petals unfurl in cool morning air</li>
                    </ul>
                    <p>These flowers have evolved to attract early pollinators like bees and butterflies when they're most active.</p>
                `
            };
        }
        
        // Evening flowers
        if (lowerQuery.includes('evening')) {
            return {
                title: "Evening Blooming Flowers",
                content: `
                    <p>Evening bloomers open as temperatures cool, typically between 4-7 PM:</p>
                    <ul>
                        <li><strong>Four O'Clock:</strong> Opens precisely around 4 PM each day</li>
                        <li><strong>Evening Primrose:</strong> Bright yellow flowers that open in late afternoon</li>
                        <li><strong>Moonflower:</strong> Large white blooms that open at dusk</li>
                        <li><strong>Angel's Trumpet:</strong> Fragrant flowers that bloom in evening</li>
                    </ul>
                    <p>Evening bloomers often have strong fragrances to attract night-flying pollinators.</p>
                `
            };
        }
        
        // Night flowers
        if (lowerQuery.includes('night')) {
            return {
                title: "Night Blooming Flowers",
                content: `
                    <p>Night bloomers are fascinating flowers that open after dark:</p>
                    <ul>
                        <li><strong>Night Jasmine:</strong> Intensely fragrant white flowers</li>
                        <li><strong>Queen of the Night:</strong> Rare cactus flower that blooms once yearly</li>
                        <li><strong>Evening Stock:</strong> Sweet-scented flowers that open at night</li>
                        <li><strong>Night Phlox:</strong> Pale flowers with strong fragrance</li>
                    </ul>
                    <p>These flowers are adapted for nocturnal pollinators like moths and bats, often featuring white or pale colors and intense fragrances.</p>
                `
            };
        }
        
        // Spring flowers
        if (lowerQuery.includes('spring')) {
            return {
                title: "Spring Flowers",
                content: `
                    <p>Spring brings the first flowers of the year, often blooming before leaves appear:</p>
                    <ul>
                        <li><strong>Crocuses:</strong> First to emerge, often through snow</li>
                        <li><strong>Daffodils:</strong> Bright yellow trumpet flowers</li>
                        <li><strong>Tulips:</strong> Colorful cup-shaped blooms</li>
                        <li><strong>Cherry Blossoms:</strong> Delicate pink and white flowers</li>
                        <li><strong>Lilacs:</strong> Fragrant purple or white flower clusters</li>
                    </ul>
                    <p>Spring flowers often emerge early to take advantage of sunlight before trees leaf out.</p>
                `
            };
        }
        
        // Pollination
        if (lowerQuery.includes('pollination') || lowerQuery.includes('pollinator')) {
            return {
                title: "Flower Pollination",
                content: `
                    <p>Pollination is the transfer of pollen from male to female flower parts:</p>
                    <ul>
                        <li><strong>Bee Pollination:</strong> Bees collect pollen and nectar, transferring pollen between flowers</li>
                        <li><strong>Butterfly Pollination:</strong> Butterflies use long tongues to reach nectar in deep flowers</li>
                        <li><strong>Wind Pollination:</strong> Some flowers rely on wind to carry pollen</li>
                        <li><strong>Bird Pollination:</strong> Hummingbirds pollinate red, tubular flowers</li>
                        <li><strong>Moth Pollination:</strong> Night-flying moths pollinate pale, fragrant flowers</li>
                    </ul>
                    <p>Different flowers have evolved specific adaptations to attract their preferred pollinators.</p>
                `
            };
        }
        
        // Default response
        return {
            title: "Flower Information",
            content: `
                <p>Thank you for your interest in flowers! Here's some general information:</p>
                <ul>
                    <li><strong>Diversity:</strong> There are over 400,000 flowering plant species worldwide</li>
                    <li><strong>Function:</strong> Flowers exist primarily for reproduction and attracting pollinators</li>
                    <li><strong>Parts:</strong> Typical flowers have petals, sepals, stamens, and pistils</li>
                    <li><strong>Colors:</strong> Flower colors attract specific pollinators and indicate nectar rewards</li>
                    <li><strong>Seasons:</strong> Different flowers bloom at different times throughout the year</li>
                </ul>
                <p>For more specific information, try asking about particular flower types, care instructions, or bloom times!</p>
            `
        };
    }
    
    /**
     * Display AI response
     */
    displayAIResponse(response) {
        const result = document.getElementById('aiResult');
        if (!result) return;
        
        result.innerHTML = `
            <div class="response-content">
                <h4><i class="fas fa-seedling me-2"></i>${response.title}</h4>
                ${response.content}
            </div>
        `;
        
        // Animate the response
        if (this.animationManager) {
            this.animationManager.animate(result, 'fadeInUp');
        }
        
        this.state.lastResponse = response;
    }
    
    /**
     * Display AI error
     */
    displayAIError(error) {
        const result = document.getElementById('aiResult');
        if (!result) return;
        
        result.innerHTML = `
            <div class="response-content text-center">
                <i class="fas fa-exclamation-triangle text-warning" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                <h4>Oops! Something went wrong</h4>
                <p>I'm having trouble generating a response right now. Please try again in a moment.</p>
                <button class="btn btn-primary" onclick="flowerAI.generateAIResponse()">
                    <i class="fas fa-redo me-2"></i>Try Again
                </button>
            </div>
        `;
        
        this.showNotification('Error generating response. Please try again.', 'error');
    }
    
    /**
     * Clear AI tool
     */
    clearAITool() {
        const input = document.getElementById('aiInput');
        const result = document.getElementById('aiResult');
        
        if (input) {
            input.value = '';
            input.focus();
        }
        
        if (result) {
            result.innerHTML = `
                <div class="response-placeholder">
                    <i class="fas fa-seedling"></i>
                    <p>Your AI-generated flower information will appear here</p>
                </div>
            `;
        }
        
        this.state.currentQuery = '';
        this.state.lastResponse = null;
        
        this.trackEvent('ai_tool_cleared');
    }
    
    /**
     * Fill AI input with text
     */
    fillAIInput(text) {
        const input = document.getElementById('aiInput');
        if (input) {
            input.value = text;
            this.autoResizeTextarea(input);
            input.focus();
        }
    }
    
    /**
     * Auto-resize textarea
     */
    autoResizeTextarea(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
    }
    
    /**
     * Scroll to section
     */
    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            const offsetTop = section.offsetTop - 80; // Account for fixed navbar
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
            
            this.currentSection = sectionId;
            this.trackEvent('section_visited', { section: sectionId });
        }
    }
    
    /**
     * Setup active section tracking
     */
    setupActiveSection() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-link[href^="#"]');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const sectionId = entry.target.id;
                    this.currentSection = sectionId;
                    
                    // Update active nav link
                    navLinks.forEach(link => {
                        link.classList.remove('active');
                        if (link.getAttribute('href') === `#${sectionId}`) {
                            link.classList.add('active');
                        }
                    });
                }
            });
        }, {
            threshold: 0.3,
            rootMargin: '-80px 0px 0px 0px'
        });
        
        sections.forEach(section => observer.observe(section));
    }
    
    /**
     * Handle voice events
     */
    handleVoiceResult(final, interim) {
        if (final) {
            console.log('Voice input received:', final);
        }
    }
    
    handleVoiceStart() {
        console.log('Voice recognition started');
    }
    
    handleVoiceEnd() {
        console.log('Voice recognition ended');
    }
    
    handleVoiceError(error) {
        console.error('Voice error:', error);
        this.showNotification('Voice recognition error. Please try again.', 'error');
    }
    
    /**
     * Handle keyboard shortcuts
     */
    handleKeyboardShortcuts(e) {
        // Ctrl + / - Show shortcuts
        if (e.ctrlKey && e.key === '/') {
            e.preventDefault();
            this.showKeyboardShortcuts();
        }
        
        // Ctrl + M - Toggle voice
        if (e.ctrlKey && e.key === 'm') {
            e.preventDefault();
            if (this.state.voiceEnabled) {
                this.voiceHandler.toggleListening();
            }
        }
        
        // Escape - Stop voice
        if (e.key === 'Escape') {
            if (this.state.voiceEnabled && this.voiceHandler.isListening) {
                this.voiceHandler.stopListening();
            }
        }
    }
    
    /**
     * Handle window resize
     */
    handleResize() {
        // Update any responsive features
        const windowWidth = window.innerWidth;
        
        if (windowWidth < 768) {
            // Mobile specific adjustments
            this.optimizeForMobile();
        } else {
            // Desktop specific adjustments
            this.optimizeForDesktop();
        }
    }
    
    /**
     * Handle scroll events
     */
    handleScroll() {
        // Update any scroll-dependent features
        const scrollTop = window.pageYOffset;
        
        // Update voice visualization based on scroll
        const voiceVisualization = document.querySelector('.voice-visualization');
        if (voiceVisualization) {
            const opacity = Math.max(0, 1 - (scrollTop / window.innerHeight));
            voiceVisualization.style.opacity = opacity;
        }
    }
    
    /**
     * Setup responsive features
     */
    setupResponsiveFeatures() {
        // Initial optimization
        this.handleResize();
        
        // Touch gestures for mobile
        this.setupTouchGestures();
    }
    
    /**
     * Setup touch gestures
     */
    setupTouchGestures() {
        let touchStartY = 0;
        let touchEndY = 0;
        
        document.addEventListener('touchstart', (e) => {
            touchStartY = e.touches[0].clientY;
        });
        
        document.addEventListener('touchend', (e) => {
            touchEndY = e.changedTouches[0].clientY;
            this.handleTouchGesture(touchStartY, touchEndY);
        });
    }
    
    /**
     * Handle touch gestures
     */
    handleTouchGesture(startY, endY) {
        const swipeThreshold = 100;
        const diff = startY - endY;
        
        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                // Swipe up - next section
                this.navigateToNextSection();
            } else {
                // Swipe down - previous section
                this.navigateToPreviousSection();
            }
        }
    }
    
    /**
     * Navigate to next section
     */
    navigateToNextSection() {
        const sections = ['home', 'flowers', 'ai-tool'];
        const currentIndex = sections.indexOf(this.currentSection);
        const nextIndex = (currentIndex + 1) % sections.length;
        this.scrollToSection(sections[nextIndex]);
    }
    
    /**
     * Navigate to previous section
     */
    navigateToPreviousSection() {
        const sections = ['home', 'flowers', 'ai-tool'];
        const currentIndex = sections.indexOf(this.currentSection);
        const prevIndex = currentIndex === 0 ? sections.length - 1 : currentIndex - 1;
        this.scrollToSection(sections[prevIndex]);
    }
    
    /**
     * Optimize for mobile
     */
    optimizeForMobile() {
        // Reduce animations for performance
        document.body.classList.add('mobile-optimized');
        
        // Adjust voice features for mobile
        if (this.state.voiceEnabled) {
            // Shorter timeouts for mobile
            this.voiceHandler.settings.continuous = false;
        }
    }
    
    /**
     * Optimize for desktop
     */
    optimizeForDesktop() {
        document.body.classList.remove('mobile-optimized');
        
        if (this.state.voiceEnabled) {
            this.voiceHandler.settings.continuous = false;
        }
    }
    
    /**
     * Disable voice features
     */
    disableVoiceFeatures() {
        const voiceButtons = document.querySelectorAll('.btn-voice, .btn-voice-input');
        voiceButtons.forEach(btn => {
            btn.disabled = true;
            btn.title = 'Voice features not available in this browser';
            btn.style.opacity = '0.5';
        });
        
        this.state.voiceEnabled = false;
    }
    
    /**
     * Setup accessibility features
     */
    setupAccessibility() {
        // Skip to content link
        this.addSkipToContentLink();
        
        // Keyboard navigation
        this.setupKeyboardNavigation();
        
        // ARIA labels
        this.setupAriaLabels();
        
        // Focus management
        this.setupFocusManagement();
    }
    
    /**
     * Add skip to content link
     */
    addSkipToContentLink() {
        const skipLink = document.createElement('a');
        skipLink.href = '#main';
        skipLink.className = 'skip-to-content';
        skipLink.textContent = 'Skip to main content';
        skipLink.style.cssText = `
            position: absolute;
            top: -40px;
            left: 6px;
            background: var(--primary-pink);
            color: white;
            padding: 8px;
            text-decoration: none;
            z-index: 10000;
            border-radius: 4px;
        `;
        
        skipLink.addEventListener('focus', () => {
            skipLink.style.top = '6px';
        });
        
        skipLink.addEventListener('blur', () => {
            skipLink.style.top = '-40px';
        });
        
        document.body.insertBefore(skipLink, document.body.firstChild);
    }
    
    /**
     * Setup keyboard navigation
     */
    setupKeyboardNavigation() {
        // Tab navigation for cards
        const cards = document.querySelectorAll('.flower-card, .feature-card');
        cards.forEach(card => {
            card.setAttribute('tabindex', '0');
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    card.click();
                }
            });
        });
    }
    
    /**
     * Setup ARIA labels
     */
    setupAriaLabels() {
        // Voice buttons
        const voiceButtons = document.querySelectorAll('.btn-voice');
        voiceButtons.forEach(btn => {
            btn.setAttribute('aria-label', 'Activate voice assistant');
        });
        
        // Sections
        const sections = document.querySelectorAll('section');
        sections.forEach((section, index) => {
            section.setAttribute('aria-label', `Section ${index + 1}`);
        });
    }
    
    /**
     * Setup focus management
     */
    setupFocusManagement() {
        // Manage focus for modals
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.addEventListener('shown.bs.modal', () => {
                const focusElement = modal.querySelector('button, input, textarea');
                if (focusElement) {
                    focusElement.focus();
                }
            });
        });
    }
    
    /**
     * Show welcome message
     */
    showWelcomeMessage() {
        if (this.state.voiceEnabled) {
            setTimeout(() => {
                this.voiceHandler.speak("Welcome to Flower AI! I'm here to help you explore the beautiful world of flowers. You can ask me questions using your voice or text.");
            }, 1500);
        }
    }
    
    /**
     * Show keyboard shortcuts
     */
    showKeyboardShortcuts() {
        const shortcuts = `
            <div class="keyboard-shortcuts">
                <h5>Keyboard Shortcuts</h5>
                <ul>
                    <li><kbd>Ctrl</kbd> + <kbd>M</kbd> - Toggle voice recognition</li>
                    <li><kbd>Ctrl</kbd> + <kbd>Enter</kbd> - Generate AI response</li>
                    <li><kbd>Ctrl</kbd> + <kbd>/</kbd> - Show this help</li>
                    <li><kbd>Esc</kbd> - Stop voice recognition</li>
                    <li><kbd>Tab</kbd> - Navigate between elements</li>
                </ul>
            </div>
        `;
        
        this.showNotification(shortcuts, 'info', 8000);
    }
    
    /**
     * Show notification
     */
    showNotification(message, type = 'info', duration = 5000) {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 100px; right: 20px; z-index: 9999; max-width: 400px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, duration);
    }
    
    /**
     * Track events (analytics placeholder)
     */
    trackEvent(eventName, data = {}) {
        console.log('Event tracked:', eventName, data);
        
        // Integration point for analytics services
        if (window.gtag) {
            window.gtag('event', eventName, data);
        }
        
        if (window.analytics) {
            window.analytics.track(eventName, data);
        }
    }
    
    /**
     * Handle initialization errors
     */
    handleInitializationError(error) {
        console.error('Initialization error:', error);
        
        this.showNotification(
            'Some features may not work properly. Please refresh the page or try a different browser.',
            'warning',
            8000
        );
    }
    
    /**
     * Get application status
     */
    getStatus() {
        return {
            ...this.state,
            currentSection: this.currentSection,
            isInitialized: this.isInitialized,
            voiceStatus: this.voiceHandler?.getStatus() || null,
            animationsEnabled: !!this.animationManager
        };
    }
    
    /**
     * Cleanup and destroy
     */
    destroy() {
        if (this.voiceHandler) {
            this.voiceHandler.destroy();
        }
        
        if (this.animationManager) {
            this.animationManager.destroy();
        }
        
        // Remove event listeners
        document.removeEventListener('keydown', this.handleKeyboardShortcuts);
        window.removeEventListener('resize', this.handleResize);
        window.removeEventListener('scroll', this.handleScroll);
        
        this.isInitialized = false;
    }
}

// Initialize application
const flowerAI = new FlowerAI();

// Export for global access
window.flowerAI = flowerAI;

// Development helpers
if (process?.env?.NODE_ENV === 'development') {
    window.debugFlowerAI = () => {
        console.log('Flower AI Status:', flowerAI.getStatus());
        console.log('Voice Handler:', flowerAI.voiceHandler);
        console.log('Animation Manager:', flowerAI.animationManager);
    };
}
