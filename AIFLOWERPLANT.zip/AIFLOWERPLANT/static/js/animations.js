/**
 * Animations Manager - Handles all animations and scroll effects
 * Provides smooth animations, scroll triggers, and interactive effects
 */

class AnimationManager {
    constructor() {
        this.scrollElements = [];
        this.isInitialized = false;
        this.animationObserver = null;
        this.lastScrollTop = 0;
        this.ticking = false;
        
        this.init();
    }
    
    /**
     * Initialize animation system
     */
    init() {
        if (this.isInitialized) return;
        
        this.setupScrollAnimations();
        this.setupParallaxEffects();
        this.setupHoverAnimations();
        this.setupLoadingAnimations();
        this.setupNavbarAnimations();
        this.setupCounterAnimations();
        
        this.isInitialized = true;
        console.log('Animation Manager initialized');
    }
    
    /**
     * Setup scroll-triggered animations using Intersection Observer
     */
    setupScrollAnimations() {
        // Create intersection observer for scroll animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        this.animationObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.triggerAnimation(entry.target);
                }
            });
        }, observerOptions);
        
        // Observe all animate-on-scroll elements
        this.observeScrollElements();
        
        // Setup scroll-based effects
        this.setupScrollEffects();
    }
    
    /**
     * Observe elements for scroll animations
     */
    observeScrollElements() {
        const elements = document.querySelectorAll('.animate-on-scroll');
        
        elements.forEach(element => {
            this.animationObserver.observe(element);
            
            // Add initial state
            element.style.opacity = '0';
            element.style.transform = 'translateY(30px)';
        });
        
        // Observe flower cards
        const flowerCards = document.querySelectorAll('.flower-card');
        flowerCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
            this.animationObserver.observe(card);
        });
        
        // Observe feature cards
        const featureCards = document.querySelectorAll('.feature-card');
        featureCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.15}s`;
            this.animationObserver.observe(card);
        });
    }
    
    /**
     * Trigger animation for an element
     */
    triggerAnimation(element) {
        element.classList.add('animated');
        
        // Add specific animation classes based on element type
        if (element.classList.contains('flower-card')) {
            element.style.animation = 'fadeInUp 0.6s ease-out forwards';
        } else if (element.classList.contains('feature-card')) {
            element.style.animation = 'fadeInScale 0.6s ease-out forwards';
        } else if (element.classList.contains('ai-tool-container')) {
            element.style.animation = 'slideInUp 0.8s ease-out forwards';
        } else {
            element.style.animation = 'fadeInUp 0.6s ease-out forwards';
        }
        
        // Unobserve after animation
        this.animationObserver.unobserve(element);
    }
    
    /**
     * Setup parallax and scroll effects
     */
    setupParallaxEffects() {
        const heroSection = document.querySelector('.hero-section');
        const floatingElements = document.querySelectorAll('.floating-flower');
        
        if (!heroSection) return;
        
        window.addEventListener('scroll', () => {
            if (!this.ticking) {
                requestAnimationFrame(() => {
                    this.updateParallax(heroSection, floatingElements);
                    this.ticking = false;
                });
                this.ticking = true;
            }
        });
    }
    
    /**
     * Update parallax effects
     */
    updateParallax(heroSection, floatingElements) {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.5;
        
        // Parallax background
        if (heroSection) {
            heroSection.style.transform = `translateY(${rate}px)`;
        }
        
        // Floating elements parallax
        floatingElements.forEach((element, index) => {
            const speed = 0.3 + (index * 0.1);
            const yPos = -(scrolled * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    }
    
    /**
     * Setup hover animations
     */
    setupHoverAnimations() {
        // Flower cards hover effects
        const flowerCards = document.querySelectorAll('.flower-card');
        flowerCards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                this.animateCardHover(card, true);
            });
            
            card.addEventListener('mouseleave', () => {
                this.animateCardHover(card, false);
            });
        });
        
        // Button hover effects
        const buttons = document.querySelectorAll('.btn');
        buttons.forEach(btn => {
            btn.addEventListener('mouseenter', () => {
                this.animateButtonHover(btn, true);
            });
            
            btn.addEventListener('mouseleave', () => {
                this.animateButtonHover(btn, false);
            });
        });
        
        // Voice button special effects
        const voiceButtons = document.querySelectorAll('.btn-voice, .btn-voice-input');
        voiceButtons.forEach(btn => {
            btn.addEventListener('mouseenter', () => {
                this.animateVoiceButtonHover(btn, true);
            });
            
            btn.addEventListener('mouseleave', () => {
                this.animateVoiceButtonHover(btn, false);
            });
        });
    }
    
    /**
     * Animate card hover effects
     */
    animateCardHover(card, isHover) {
        const icon = card.querySelector('.flower-icon');
        const examples = card.querySelectorAll('.flower-tag');
        
        if (isHover) {
            card.style.transform = 'translateY(-10px) scale(1.02)';
            card.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.15)';
            
            if (icon) {
                icon.style.transform = 'scale(1.15) rotate(10deg)';
            }
            
            examples.forEach((tag, index) => {
                setTimeout(() => {
                    tag.style.transform = 'scale(1.1)';
                    tag.style.background = 'var(--primary-pink)';
                    tag.style.color = 'white';
                }, index * 50);
            });
        } else {
            card.style.transform = 'translateY(0) scale(1)';
            card.style.boxShadow = '0 5px 20px rgba(0, 0, 0, 0.1)';
            
            if (icon) {
                icon.style.transform = 'scale(1) rotate(0deg)';
            }
            
            examples.forEach(tag => {
                tag.style.transform = 'scale(1)';
                tag.style.background = 'rgba(233, 30, 99, 0.1)';
                tag.style.color = 'var(--primary-pink)';
            });
        }
    }
    
    /**
     * Animate button hover effects
     */
    animateButtonHover(btn, isHover) {
        if (isHover) {
            btn.style.transform = 'translateY(-3px) scale(1.05)';
            btn.style.boxShadow = '0 8px 25px rgba(0, 0, 0, 0.2)';
        } else {
            btn.style.transform = 'translateY(0) scale(1)';
            btn.style.boxShadow = 'none';
        }
    }
    
    /**
     * Animate voice button hover effects
     */
    animateVoiceButtonHover(btn, isHover) {
        const icon = btn.querySelector('i');
        
        if (isHover) {
            btn.style.transform = 'scale(1.1)';
            btn.style.boxShadow = '0 0 20px rgba(255, 64, 129, 0.5)';
            
            if (icon) {
                icon.style.animation = 'pulse 0.6s ease-in-out infinite';
            }
        } else {
            btn.style.transform = 'scale(1)';
            btn.style.boxShadow = 'none';
            
            if (icon) {
                icon.style.animation = 'none';
            }
        }
    }
    
    /**
     * Setup loading animations
     */
    setupLoadingAnimations() {
        // Page load animation
        window.addEventListener('load', () => {
            this.animatePageLoad();
        });
        
        // Loading overlay animations
        this.setupLoadingOverlay();
    }
    
    /**
     * Animate page load
     */
    animatePageLoad() {
        // Fade in hero content
        const heroContent = document.querySelector('.hero-content');
        const heroVisual = document.querySelector('.hero-visual');
        
        if (heroContent) {
            heroContent.style.opacity = '0';
            heroContent.style.transform = 'translateY(50px)';
            
            setTimeout(() => {
                heroContent.style.transition = 'all 1s ease-out';
                heroContent.style.opacity = '1';
                heroContent.style.transform = 'translateY(0)';
            }, 300);
        }
        
        if (heroVisual) {
            heroVisual.style.opacity = '0';
            heroVisual.style.transform = 'translateX(50px)';
            
            setTimeout(() => {
                heroVisual.style.transition = 'all 1s ease-out';
                heroVisual.style.opacity = '1';
                heroVisual.style.transform = 'translateX(0)';
            }, 600);
        }
        
        // Start voice visualization animation
        this.startVoiceVisualization();
    }
    
    /**
     * Setup loading overlay
     */
    setupLoadingOverlay() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        
        if (loadingOverlay) {
            // Show loading function
            window.showLoading = () => {
                loadingOverlay.classList.add('active');
            };
            
            // Hide loading function
            window.hideLoading = () => {
                loadingOverlay.classList.remove('active');
            };
        }
    }
    
    /**
     * Setup navbar animations
     */
    setupNavbarAnimations() {
        const navbar = document.querySelector('.navbar');
        let lastScrollTop = 0;
        
        if (!navbar) return;
        
        window.addEventListener('scroll', () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            // Add/remove scrolled class
            if (scrollTop > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
            
            // Hide/show navbar on scroll
            if (scrollTop > lastScrollTop && scrollTop > 200) {
                // Scrolling down
                navbar.style.transform = 'translateY(-100%)';
            } else {
                // Scrolling up
                navbar.style.transform = 'translateY(0)';
            }
            
            lastScrollTop = scrollTop;
        });
    }
    
    /**
     * Setup counter animations
     */
    setupCounterAnimations() {
        const counters = document.querySelectorAll('[data-count]');
        
        counters.forEach(counter => {
            this.animationObserver.observe(counter);
            
            counter.addEventListener('animationstart', () => {
                this.animateCounter(counter);
            });
        });
    }
    
    /**
     * Animate counter
     */
    animateCounter(counter) {
        const target = parseInt(counter.dataset.count);
        const duration = 2000;
        const start = 0;
        const increment = target / (duration / 16);
        let current = start;
        
        const timer = setInterval(() => {
            current += increment;
            counter.textContent = Math.floor(current);
            
            if (current >= target) {
                counter.textContent = target;
                clearInterval(timer);
            }
        }, 16);
    }
    
    /**
     * Start voice visualization animation
     */
    startVoiceVisualization() {
        const waveBars = document.querySelectorAll('.wave-bar');
        
        waveBars.forEach((bar, index) => {
            setInterval(() => {
                const height = Math.random() * 40 + 10;
                bar.style.height = `${height}px`;
            }, 150 + (index * 50));
        });
    }
    
    /**
     * Setup scroll effects
     */
    setupScrollEffects() {
        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
        
        // Add scroll to top button
        this.addScrollToTopButton();
    }
    
    /**
     * Add scroll to top button
     */
    addScrollToTopButton() {
        const scrollBtn = document.createElement('div');
        scrollBtn.className = 'scroll-to-top';
        scrollBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        document.body.appendChild(scrollBtn);
        
        // Show/hide based on scroll position
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });
    }
    
    /**
     * Animate element with custom options
     */
    animate(element, animation, options = {}) {
        if (!element) return;
        
        const defaultOptions = {
            duration: '0.6s',
            easing: 'ease-out',
            delay: '0s',
            fillMode: 'forwards'
        };
        
        const animationOptions = { ...defaultOptions, ...options };
        
        element.style.animation = `${animation} ${animationOptions.duration} ${animationOptions.easing} ${animationOptions.delay} ${animationOptions.fillMode}`;
        
        return new Promise(resolve => {
            element.addEventListener('animationend', resolve, { once: true });
        });
    }
    
    /**
     * Create custom keyframe animation
     */
    createKeyframes(name, keyframes) {
        const style = document.createElement('style');
        style.textContent = `
            @keyframes ${name} {
                ${keyframes}
            }
        `;
        document.head.appendChild(style);
    }
    
    /**
     * Destroy animation manager
     */
    destroy() {
        if (this.animationObserver) {
            this.animationObserver.disconnect();
        }
        
        // Remove event listeners
        window.removeEventListener('scroll', this.updateParallax);
        window.removeEventListener('load', this.animatePageLoad);
        
        this.isInitialized = false;
    }
}

// Create additional keyframe animations
const additionalKeyframes = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes fadeInScale {
        from {
            opacity: 0;
            transform: scale(0.8) translateY(20px);
        }
        to {
            opacity: 1;
            transform: scale(1) translateY(0);
        }
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(50px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes bounceIn {
        0% {
            opacity: 0;
            transform: scale(0.3);
        }
        50% {
            opacity: 1;
            transform: scale(1.1);
        }
        100% {
            opacity: 1;
            transform: scale(1);
        }
    }
    
    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translateX(-50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes rotateIn {
        from {
            opacity: 0;
            transform: rotate(-180deg) scale(0.5);
        }
        to {
            opacity: 1;
            transform: rotate(0deg) scale(1);
        }
    }
`;

// Add animations to document
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalKeyframes;
document.head.appendChild(styleSheet);

// Export for global use
window.AnimationManager = AnimationManager;
