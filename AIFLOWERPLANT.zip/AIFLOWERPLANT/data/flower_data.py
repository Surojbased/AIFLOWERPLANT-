"""
In-memory storage for flower data
This module manages the flower database using Python dictionaries and lists
"""

# In-memory flower database
flowers_db = [
    {
        "name": "Sunflower",
        "scientific_name": "Helianthus annuus",
        "blooming_time": "morning",
        "color": "Yellow",
        "family": "Asteraceae",
        "description": "",
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": "2024-01-01T00:00:00Z"
    },
    {
        "name": "Moonflower",
        "scientific_name": "Ipomoea alba",
        "blooming_time": "night",
        "color": "White",
        "family": "Convolvulaceae",
        "description": "",
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": "2024-01-01T00:00:00Z"
    },
    {
        "name": "Four O'Clock",
        "scientific_name": "Mirabilis jalapa",
        "blooming_time": "evening",
        "color": "Pink, Red, Yellow, White",
        "family": "Nyctaginaceae",
        "description": "",
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": "2024-01-01T00:00:00Z"
    },
    {
        "name": "Morning Glory",
        "scientific_name": "Ipomoea purpurea",
        "blooming_time": "morning",
        "color": "Purple, Blue, Pink, White",
        "family": "Convolvulaceae",
        "description": "",
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": "2024-01-01T00:00:00Z"
    },
    {
        "name": "Evening Primrose",
        "scientific_name": "Oenothera biennis",
        "blooming_time": "evening",
        "color": "Yellow",
        "family": "Onagraceae",
        "description": "",
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": "2024-01-01T00:00:00Z"
    },
    {
        "name": "Night Blooming Cereus",
        "scientific_name": "Epiphyllum oxypetalum",
        "blooming_time": "night",
        "color": "White",
        "family": "Cactaceae",
        "description": "",
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": "2024-01-01T00:00:00Z"
    },
    {
        "name": "Marigold",
        "scientific_name": "Tagetes",
        "blooming_time": "morning",
        "color": "Orange, Yellow",
        "family": "Asteraceae",
        "description": "",
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": "2024-01-01T00:00:00Z"
    },
    {
        "name": "Jasmine",
        "scientific_name": "Jasminum",
        "blooming_time": "evening",
        "color": "White, Yellow",
        "family": "Oleaceae",
        "description": "",
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": "2024-01-01T00:00:00Z"
    }
]

def get_all_flowers():
    """Get all flowers from the database"""
    return flowers_db.copy()

def get_flower_by_name(name):
    """Get a specific flower by name (case-insensitive)"""
    for flower in flowers_db:
        if flower['name'].lower() == name.lower():
            return flower.copy()
    return None

def get_flowers_by_blooming_time(blooming_time):
    """Get flowers filtered by blooming time"""
    return [flower.copy() for flower in flowers_db if flower['blooming_time'] == blooming_time.lower()]

def add_flower(name, blooming_time, description="", scientific_name="", color="", family=""):
    """Add a new flower to the database"""
    from datetime import datetime
    
    new_flower = {
        "name": name,
        "scientific_name": scientific_name,
        "blooming_time": blooming_time.lower(),
        "color": color,
        "family": family,
        "description": description,
        "ai_trivia": [],
        "ai_care_tips": {},
        "created_at": datetime.now().isoformat() + "Z"
    }
    
    flowers_db.append(new_flower)
    return new_flower.copy()

def update_flower_ai_content(name, description=None, trivia=None, care_tips=None):
    """Update AI-generated content for a flower"""
    for flower in flowers_db:
        if flower['name'].lower() == name.lower():
            if description is not None:
                flower['description'] = description
            if trivia is not None:
                flower['ai_trivia'] = trivia
            if care_tips is not None:
                flower['ai_care_tips'] = care_tips
            return flower.copy()
    return None

def get_blooming_time_stats():
    """Get statistics about blooming times"""
    stats = {"morning": 0, "evening": 0, "night": 0}
    for flower in flowers_db:
        blooming_time = flower['blooming_time']
        if blooming_time in stats:
            stats[blooming_time] += 1
    return stats
