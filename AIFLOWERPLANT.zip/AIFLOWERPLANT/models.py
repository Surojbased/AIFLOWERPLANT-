from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'user_db'  # must match table name in MySQL

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100))  # nullable=True based on screenshot
    password_hash = db.Column(db.String(255), nullable=False)
